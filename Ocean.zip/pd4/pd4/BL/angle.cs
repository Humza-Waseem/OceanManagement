﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pd4.BL
{
    class Angle
    {
        
        public int degree;
        public float minute;
        public  char direction;

        public Angle(int degree,float minute,char direction)
        {
            this.degree = degree;
            this.minute = minute;
            this.direction = direction;

        }
        public Angle()
        {

        }

        public void changeAngleValueInDegreesAndMinutes()
        {
            Console.WriteLine( degree +  "\u00b0" + minute + "'" + direction); 
        }
    }
   

}
