﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pd4.BL
{
    class Ship
    {
        public string serialNumber;
        public Angle latitude;
        public Angle longitude;

        public string checkSerialnumber(int latd, int lond, float latm, float lonm, char latdi, char londi, List<Ship> listofships)
        {

            foreach (Ship i in listofships)
            {
                if (i.latitude.degree == latd && i.latitude.minute == latm && i.latitude.direction == latdi && i.longitude.degree == lond && i.longitude.minute == lonm && i.longitude.direction == londi)
                {
                    return i.serialNumber;
                }
            }
            return null;
        }

        public Ship(string serialNumber, Angle latitude, Angle longitude)
        {
            this.serialNumber = serialNumber;
            this.latitude = latitude;
            this.longitude = longitude;

        }
        public Ship()
        {

        }
        
      
        public void addShipDataToList(List<Ship> ships, Ship n)
        {
            ships.Add(n);
        }
        public string latitudeFormat()
        {
            return latitude.degree + "\u00b0" + latitude.minute + "'" + latitude.direction;
        }
        public string longitudeFormat()
        {
            return longitude.degree + "\u00b0" + longitude.minute + "'" + longitude.direction;
        }
        public void printShipPosition()
        {
            Console.WriteLine(serialNumber);
        }
    }
    
    
   

}
