﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pd4.BL;
namespace pd4
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Angle> angles = new List<Angle>();
            List<Ship> ships = new List<Ship>();


            int option;

            do
            {
                Console.Clear();
                option = mainMenu();
                if (option == 1)
                {
                    Ship n = addShip();
                    n.addShipDataToList(ships, n);

                }
                if (option == 2)
                {
                    viewShipPosition(ships);
                }
                if (option == 3)
                {
                    viewShipSerialNumber(ships);
                }
                if (option == 4)
                {
                    changeShipPosition(ships);
                }
              
                
            }
            while (option != 5);
            Console.ReadKey();

        }
        static int mainMenu()
        {
            int option = 5;
            Console.WriteLine("1.Add Ship");
            Console.WriteLine("2.View Ship Position");
            Console.WriteLine("3.View Ship Serial Number");
            Console.WriteLine("4.Change Ship Position");
            Console.WriteLine("5.Exit");
            Console.WriteLine("Enter your Option : ");
            option = int.Parse(Console.ReadLine());

            return option;
        }
        static Ship addShip()
        {

            Ship s = new Ship();
            s.latitude = new Angle();
            s.longitude = new Angle();


            Console.Clear();
            Console.WriteLine("Enter Ship Number: ");
            s.serialNumber = Console.ReadLine();


            // <<<<  Latitude Directionh >>>>
            Console.WriteLine(">>>>>>Enter Ship Latitude<<<<<<");

            Console.WriteLine("Enter Latitude’s Degree: ");
            s.latitude.degree = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Latitude's Minute:");
            s.latitude.minute = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter Latitude's Direction:");
            s.latitude.direction = char.Parse(Console.ReadLine());

            Console.WriteLine(">>>>>>>Enter Ship Longitude<<<<<<<:");

            Console.WriteLine("Enter Longitude's Degree:");
            s.longitude.degree = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Longitude's Minute:");
            s.longitude.minute = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter Longitude's Direction:");
            s.longitude.direction = char.Parse(Console.ReadLine());


            Ship s1 = new Ship(s.serialNumber, s.latitude, s.longitude);
            return s1;


        }
        static void viewShipPosition(List<Ship> ships)
        {
            Console.Clear();
            Ship s = new Ship();
            Console.WriteLine("Enter the Serial Number of Ship : ");
            s.serialNumber = Console.ReadLine();

            foreach (Ship h in ships)
            {
                if (h.serialNumber == s.serialNumber)
                {
                    Console.WriteLine("Ship is at" + h.latitudeFormat() + "and" + h.longitudeFormat());
                }
                else
                {
                    Console.WriteLine("Invalid Input!");
                }
            }



        }

        static void viewShipSerialNumber(List<Ship> ships)
        {
            Console.Clear();
            Console.WriteLine("<<<<< Enter the ship Latitude >>>>> ");
            Console.WriteLine("Enter Latitude's Degree:");
            int latitudeDegree = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Latitude's Minute:");
            float latitudeMinute = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter Latitude's Direction:");
            char latitudeDirection = char.Parse(Console.ReadLine());

            Console.WriteLine("<<<<< Enter Ship Longitude >>>>>");
            Console.WriteLine("Enter Longitude's Degree:");
            int longitudeDegree = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Longitude's Minute:");
            float longitudeMinute = float.Parse(Console.ReadLine());

            Console.WriteLine("Enter Longitude's Direction:");
            char longitudeDirection = char.Parse(Console.ReadLine());

            Ship s = new Ship();
            string serNo = s.checkSerialnumber(latitudeDirection, longitudeDegree, latitudeMinute, longitudeMinute, latitudeDirection, longitudeDirection, ships);
            Console.WriteLine("Serial number of Ship is :{0}" , serNo);

        }
        static void changeShipPosition(List<Ship> ships)
        {
            Console.Clear();
            Console.WriteLine("Enter the Ship's Serial Number To change its Postion : ");
            string position = Console.ReadLine();

            foreach (Ship i in ships)
            {
                if (i.serialNumber == position)
                {
                    Console.WriteLine("<<<<<< Enter Ship Latitude >>>>>>");
                    Console.WriteLine("Enter Latitude's Degree:");
                    i.latitude.degree = int.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Latitude's Minute:");
                    i.latitude.minute = float.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Latitude's Direction:");
                    i.latitude.direction = char.Parse(Console.ReadLine());

                    Console.WriteLine("<<<<<< Enter Ship Longitude >>>>>>");
                    Console.WriteLine("Enter Longitude's Degree:");
                    i.longitude.degree = int.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Longitude's Minute:");
                    i.longitude.minute = float.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Longitude's Direction:");
                    i.longitude.direction = char.Parse(Console.ReadLine());
                }
            }
        }
    }
}




